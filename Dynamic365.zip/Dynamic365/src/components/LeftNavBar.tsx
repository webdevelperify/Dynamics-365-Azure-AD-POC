import React from 'react';
import { Nav, INavLink, INavLinkGroup } from 'office-ui-fabric-react/lib/Nav';
import { withRouter } from 'react-router-dom';
import { initializeIcons } from 'office-ui-fabric-react/lib/Icons';

export const LeftNavBar = withRouter((props: any) => {

    initializeIcons();

    const navLinkGroups: INavLinkGroup[] = [
        {
          links: [
            {
              name: 'Resource Management',
              url: '#',
              expandAriaLabel: 'Expand Resource Management',
              collapseAriaLabel: 'Collapse Resource Management',
              links: [
                {
                  name: 'Report Attrition',
                  url: '/',
                  key: 'report-attrition',
                  icon: 'DecisionSolid'
                },
                {
                  name: 'Column Mapping',
                  url: '/rmcolumnMapping',
                  key: 'rmcolumnmapping',
                  icon: 'BranchCompare'
                },
                {
                  name: 'Other Report Types',
                  url: '/otherReportType',
                  key: 'otherReportType',
                  icon: 'ReportAdd'
                },
                {
                  name: 'Power BI Report',
                  url: '/#',
                  key: 'rmpowerbireport',
                  icon: 'ReportLock'
                }
              ],
              isExpanded: true,
            },
            {
                name: 'Issue & News Management',
                url: '#',
                expandAriaLabel: 'Expand Management',
                collapseAriaLabel: 'Collapse Management',
                links: [
                  {
                    name: 'Issue Management',
                    url: '/issue-management',
                    key: 'issue-management',
                    icon: 'IssueSolid'
                  },
                  {
                    name: 'News Management',
                    url: '/news-management',
                    key: 'news-management',
                    icon: 'News'
                  },
                  {
                    name: 'Power BI Report',
                    url: '/#',
                    key: 'impowerbireport',
                    icon: 'ReportLock'
                  },
                ],
                isExpanded: true,
              },
              {
                name: 'Finance Management',
                url: '#',
                expandAriaLabel: 'Expand Management',
                collapseAriaLabel: 'Collapse Management',
                links: [
                  {
                    name: 'Column Mapping',
                    url: '/fmcolumnMapping',
                    key: 'fmcolumnmapping',
                    icon: 'BranchCompare'
                  },
                  {
                    name: 'Employee Connect',
                    url: '/empConnect',
                    key: 'empConnect',
                    icon: 'TemporaryUser'
                  },
                  {
                    name: 'Power BI Report',
                    url: '/#',
                    key: 'fmpowerbireport',
                    icon: 'ReportLock'
                  }
                ],
                isExpanded: true,
              }
          ]
        },
    ];

    const _onLinkClick = (ev?: React.MouseEvent<HTMLElement>, item?: INavLink) => {   
        ev?.preventDefault() 
        if (item && item.name === 'Report Attrition') {
            props.history.push("/");
        }else if (item && item.name === 'Issue Management') {
            props.history.push("/issue-management");
        }else if (item && item.name === 'News Management') {
          props.history.push("/news-management");
        }else if (item && item.key === 'rmcolumnmapping') {
          props.history.push("/rmcolumnMapping");
        }else if (item && item.name === 'Other Report Types') {
          props.history.push("/otherReportType");
        }else if (item && item.key === 'fmcolumnmapping') {
          props.history.push("/fmcolumnMapping");
        }else if (item && item.name === 'Employee Connect') {
          props.history.push(item.url);
        }
        return false;
      }

    return (
        <>
          <div className="panelBody">
              <Nav
                  onLinkClick={_onLinkClick}
                  selectedKey="key3"
                  ariaLabel="Nav basic example"
                  groups={navLinkGroups}
                  className={"menuOptionsLeftSide"}
              />
          </div>
      </>
    )
})