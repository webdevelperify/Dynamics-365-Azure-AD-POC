// src/config/AdalConfig.js
export default {
  tenant: '3e738f10-e49d-4867-8a0d-2913fda8da81',
  clientId: 'adf1d6dc-c5bc-4982-a23f-c012205ba75e',
  cacheLocation: 'localStorage',
  endpoints: {
    graphApiUri: "https://graph.microsoft.com",
    crmUrl: "https://demoapp.crm8.dynamics.com"
  }
}