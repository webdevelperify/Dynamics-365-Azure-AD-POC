// src/config/ApiConfig.js
export default {
  baseURL: "http://localhost:8080/api" // something like "http://my-host-name.xyz/api"
}