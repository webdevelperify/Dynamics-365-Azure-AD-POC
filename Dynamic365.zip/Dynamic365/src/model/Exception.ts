export default interface Exception {
    timestamp: Date | null,
    status: number | null,
    error: string | null,
    message: string | null,
    path: string | null
}