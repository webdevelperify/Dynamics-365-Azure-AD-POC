// src/config/AdalConfig.js
export default {
  tenant: 'c0a755ca-2d83-4910-848d-52ec15e522f2',
  clientId: 'c71fb71a-33b4-4bc9-bc69-8222f370b456',
  cacheLocation: 'localStorage',
  endpoints: {
    graphApiUri: "https://graph.microsoft.com",
    sharePointUri: "https://amadeusitc32839.sharepoint.com",
    crmUrl: "https://dff-testdevaos.sandbox.ax.uae.dynamics.com"
  }
}