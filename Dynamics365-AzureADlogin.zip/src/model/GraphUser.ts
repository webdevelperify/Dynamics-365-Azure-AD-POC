import Exception from "./Exception";

export default interface GraphUser {
    city: string,
    country: string,
    department: string,
    displayName: string,
    employeeId: string,
    jobTitle: string,
    mail: string,
    businessPhones: string[],
    givenName: string,
    id: string,
    mobilePhone: string,
    officeLocation: string | null,
    preferredLanguage: string,
    surname: string,
    userPrincipalName: string
}

export interface IGraphUsersResponse {
    response: GraphUser[],
    error: Exception
}

export interface IGraphUserResponse {
    response: GraphUser,
    error: Exception
}