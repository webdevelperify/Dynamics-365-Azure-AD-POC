export default interface ADLAUser {
    userName: string,
    profile: {
        ageGroup: string,
        aio: string,
        amr: Array<string>,
        aud: string,
        exp: number,
        family_name: string,
        given_name: string
        groups: Array<string>,
        iat: number,
        ipaddr: string,
        iss: string,
        name: string,
        nbf: number,
        nonce: string,
        oid: string,
        rh: string,
        sub: string,
        tid: string,
        unique_name: string,
        upn: string,
        uti: string,
        ver: string
    }
}