export interface AxiosErrorObject {
    response: {
        data: any,
        status: number
    },
    config : {
        url: string
    }
}