import React, {useEffect, useState} from 'react';
import { LeftNavBar } from './components/LeftNavBar';
import './index.css';
import AuthContext from './services/Auth';
import {BrowserRouter as Router} from 'react-router-dom';
import { IPersonaSharedProps, Persona, PersonaSize, PersonaPresence } from 'office-ui-fabric-react/lib/Persona';
import GraphAPI from './services/GraphAPI';
import ADLAUser from './model/ADALUser';
import ITCHeaderLogo from './images/ITCHeaderLogo.jpg';

function App() {
  const userProfileLoggedIn: ADLAUser = AuthContext.getCachedUser();

  const [loggedInUser,setLoggedInUser] = useState<IPersonaSharedProps>({
    imageInitials: 'TG',
    text: userProfileLoggedIn.profile.name,
    secondaryText: userProfileLoggedIn.userName,
    tertiaryText: 'Available'
  });
  
  useEffect(()=>{
    GraphAPI.get("https://graph.microsoft.com/v1.0/me/photo/$value", {
      responseType: 'arraybuffer',
      headers: {
        'Content-Type': 'image/jpeg'
      }
    }).then((userPhoto:any) => {
          const blobUrl = new Buffer(userPhoto.data, 'binary').toString('base64');
          setLoggedInUser({...loggedInUser, imageUrl: `data:image/jpeg;base64,${blobUrl}`});
    })
  },[])

  return (
      <Router>
            <div className="ms-Grid topHeader" dir="ltr">
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm12 mg-bottom-10" style={{backgroundColor: "#fff"}}>
                  <div className="ms-Grid-col ms-sm4 mg-bottom-10" style={{fontSize: "20px", fontWeight: "bolder", color: "purple"}}>
                    <img src={ITCHeaderLogo} style={{width: 120, marginRight:"10px"}}  />
                    GIC Reporting Tool
                  </div>
                  <div className="ms-Grid-col ms-sm6 mg-bottom-10"></div>
                  <div className="ms-Grid-col ms-sm2" style={{marginTop:"10px"}}>
                    <Persona
                        {...loggedInUser}
                        size={PersonaSize.size48}
                        presence={PersonaPresence.online}
                        imageAlt={`${userProfileLoggedIn.profile.name}, status is Available`}
                      />
                  </div>
                </div>
                <div className="ms-Grid-col ms-sm4 ms-md2">
                  <LeftNavBar />
                </div>
                <div className="ms-Grid-col ms-sm8 ms-md10 mg-bottom-40">
                  
                </div>
                <div className="ms-Grid-col ms-sm12 footerLayout">
                    <span>&copy; GIC Department</span>
                </div>
              </div>
            </div>
      </Router>
  );
}

export default App;
